var textarea;
var content;
function edToolbar(obj) {   
    document.write("<img class=\"button\" src=\"e/obold.gif\" name=\"btnBold\" title=\"Bold\" onClick=\"doAddTags('<b>','</b>','" + obj + "')\">");
    document.write("<img class=\"button\" src=\"e/oitalic.gif\" name=\"btnItalic\" title=\"Italic\" onClick=\"doAddTags('<em>','</em>','" + obj + "')\">");
    document.write("<img class=\"button\" src=\"e/oleft.gif\" name=\"btnQuote\" title=\"Quote\" onClick=\"doAddTags('<p align=left>','</p>','" + obj + "')\">"); 
    document.write("<img class=\"button\" src=\"e/ocenter.gif\" name=\"btnQuote\" title=\"Quote\" onClick=\"doAddTags('<center>','</center>','" + obj + "')\">"); 
    document.write("<img class=\"button\" src=\"e/ojustif.gif\" name=\"btnQuote\" title=\"Quote\" onClick=\"doAddTags('<p align=justify>','</p>','" + obj + "')\">"); 
    document.write("<img class=\"button\" src=\"e/obreak.gif\" name=\"btnCode\" title=\"Code\" onClick=\"doAddTags('<br>','','" + obj + "')\">");
    document.write("<img class=\"button\" src=\"e/o.gif\" name=\"btnCode\" title=\"Code\" onClick=\"doAddTags('<br>','','" + obj + "')\">");
    document.write("<img class=\"button\" src=\"e/ored.gif\" name=\"btnCode\" title=\"Code\" onClick=\"doAddTags('<font color=red>','</font>','" + obj + "')\">");
    document.write("<img class=\"button\" src=\"e/oblue.gif\" name=\"btnCode\" title=\"Code\" onClick=\"doAddTags('<font color=blue>','</font>','" + obj + "')\">");
    document.write("<img class=\"button\" src=\"e/oteal.gif\" name=\"btnCode\" title=\"Code\" onClick=\"doAddTags('<font color=teal>','</font>','" + obj + "')\">");
    document.write("<img class=\"button\" src=\"e/ogray.gif\" name=\"btnCode\" title=\"Code\" onClick=\"doAddTags('<font color=gray>','</font>','" + obj + "')\">");
    document.write("<br>");
		}

function doAddTags(tag1,tag2,obj)
{
textarea = document.getElementById(obj);

		if (document.selection) 
			{
				textarea.focus();
				var sel = document.selection.createRange();
				//alert(sel.text);
				sel.text = tag1 + sel.text + tag2;
			}
   else 
    {  
		var len = textarea.value.length;
	    var start = textarea.selectionStart;
		var end = textarea.selectionEnd;		
		var scrollTop = textarea.scrollTop;
		var scrollLeft = textarea.scrollLeft;
        var sel = textarea.value.substring(start, end);
		var rep = tag1 + sel + tag2;
        textarea.value =  textarea.value.substring(0,start) + rep + textarea.value.substring(end,len);
		
		textarea.scrollTop = scrollTop;
		textarea.scrollLeft = scrollLeft;
	}
}

function doList(tag1,tag2,obj){
textarea = document.getElementById(obj);

		if (document.selection) 
			{
				textarea.focus();
				var sel = document.selection.createRange();
				var list = sel.text.split('\n');
		
				for(i=0;i<list.length;i++) 
				{
				list[i] = '<li>' + list[i] + '</li>';
				}
				sel.text = tag1 + '\n' + list.join("\n") + '\n' + tag2;
				
			} else
			{

		var len = textarea.value.length;
	    var start = textarea.selectionStart;
		var end = textarea.selectionEnd;
		var i;
		var scrollTop = textarea.scrollTop;
		var scrollLeft = textarea.scrollLeft;
        var sel = textarea.value.substring(start, end);		
		var list = sel.split('\n');
		
		for(i=0;i<list.length;i++) 
		{
		list[i] = '<li>' + list[i] + '</li>';
		}
        
		var rep = tag1 + '\n' + list.join("\n") + '\n' +tag2;
		textarea.value =  textarea.value.substring(0,start) + rep + textarea.value.substring(end,len);
		
		textarea.scrollTop = scrollTop;
		textarea.scrollLeft = scrollLeft;
 }
}